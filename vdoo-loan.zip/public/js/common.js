
function create(obj, id2)
{
    let code = $(obj).val();
    if(code=='create')
    {
        // show the popup modal
        $(id2).modal('show');
    }

}